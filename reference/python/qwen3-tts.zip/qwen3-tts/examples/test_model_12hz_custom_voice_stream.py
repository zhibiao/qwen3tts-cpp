# coding=utf-8
# Copyright 2026 The Alibaba Qwen team.
# SPDX-License-Identifier: Apache-2.0

import time

import numpy as np
import soundfile as sf
import torch

from qwen_tts import Qwen3TTSModel


def main():
    model_path = "./models/Qwen3-TTS-12Hz-0.6B-CustomVoice/"
    tts = Qwen3TTSModel.from_pretrained(
        model_path,
        device_map="cuda:0",
        dtype=torch.bfloat16,
        attn_implementation="sdpa",
    )

    started_at = time.perf_counter()
    audio_chunks = []
    for index, (audio, sample_rate, codes) in enumerate(
        tts.generate_custom_voice_stream(
            text="其实我真的有发现，我是一个特别善于观察别人情绪的人。",
            language="Chinese",
            speaker="Ryan",
            chunk_frames=12,
            decoder_context_frames=48,
            max_new_tokens=2048,
        )
    ):
        elapsed = time.perf_counter() - started_at
        audio_chunks.append(audio)
        sf.write(f"qwen3_tts_stream_chunk_{index}.wav", audio, sample_rate)
        print(
            f"chunk={index} elapsed={elapsed:.3f}s "
            f"audio={len(audio) / sample_rate:.3f}s codes={tuple(codes.shape)}"
        )

    sf.write(
        "qwen3_tts_stream_full.wav",
        np.concatenate(audio_chunks),
        sample_rate,
    )
    print(f"total={time.perf_counter() - started_at:.3f}s")


if __name__ == "__main__":
    main()
